/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
import javax.swing.table.DefaultTableModel;
public class Main {
     public static void main(String[] args) {
        // Create a table model
        DefaultTableModel tableModel = new DefaultTableModel(
            new Object [][] {},
            new String [] {"StudentId", "Science", "English", "Sinhala", "Maths", "ICT", "Marks", "Average"}
        );

        // Create the model and view
        StudentScoreModel model = new StudentScoreModel(tableModel);
        scorepage1 view = new scorepage1(model);
        
        // Create the controller and pass in the model and view
        ScoreController controller = new ScoreController(view, model);

        // No need to set default close operation or visibility here since it's done in view
    }
    
}
