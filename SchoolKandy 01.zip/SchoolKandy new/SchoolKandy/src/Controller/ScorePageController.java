/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author User
 */
import Model.Student;
import View.ScorePageView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ScorePageController {
    private final ScorePageView view;
    private final Student model;

    public ScorePageController(ScorePageView view, Student model) {
        this.view = view;
        this.model = model;

        // Attach listeners to view buttons
        this.view.addBackButtonListener(new BackButtonListener());
        this.view.addSearchButtonListener(new SearchButtonListener());
        this.view.addRefreshButtonListener(new RefreshButtonListener());
        this.view.addAddButtonListener(new AddButtonListener());
        this.view.addUpdateButtonListener(new UpdateButtonListener());
        this.view.addDeleteButtonListener(new DeleteButtonListener());

        // Initialize table with empty data initially
        updateTable(new Object[][]{}, new String[]{"StudentId", "Science", "English", "Sinhala", "Maths", "ICT", "Marks", "Average"});
    }

    // Listener classes for each button action
    private class BackButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle back button action
            // Example: Go back to previous view or close the current view
        }
    }

    private class SearchButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle search button action
            // Example: Perform search based on search index
        }
    }

    private class RefreshButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle refresh button action
            // Example: Clear fields or reload data
        }
    }

    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle add button action
            // Example: Add a new student record to the model and update the view
        }
    }

    private class UpdateButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle update button action
            // Example: Update an existing student record in the model and update the view
        }
    }

    private class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle delete button action
            // Example: Delete a student record from the model and update the view
        }
    }

    private void updateTable(Object[][] data, String[] columnNames) {
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        view.setTableData(data, columnNames);
    }
}
