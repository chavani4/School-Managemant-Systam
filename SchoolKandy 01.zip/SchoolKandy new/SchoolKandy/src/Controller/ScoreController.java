/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author User
 */
import javax.swing.table.DefaultTableModel;
public class ScoreController {
      private scorepage1 view;
    private StudentScoreModel model;

    public ScoreController(scorepage1 view, StudentScoreModel model) {
        this.view = view;
        this.model = model;
        
        // Attach action listener to the "Add" button
        view.getBtnadd().addActionListener((java.awt.event.ActionEvent evt) -> {
            btnaddActionPerformed(evt);
        });
    }

    private void btnaddActionPerformed(java.awt.event.ActionEvent evt) {                                       
        // Delegate to the view's method
        view.btnaddActionPerformed(evt);
    }

    
}
