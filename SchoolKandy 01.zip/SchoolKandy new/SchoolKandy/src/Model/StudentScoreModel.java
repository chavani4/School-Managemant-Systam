/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author User
 */
import javax.swing.table.DefaultTableModel;

public class StudentScoreModel {
    private DefaultTableModel tableModel;

    public StudentScoreModel(DefaultTableModel tableModel) {
        this.tableModel = tableModel;
    }

    public void addScore(Object[] row) {
        tableModel.addRow(row);
    }

    
}
