/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author User
 */
public class ScoreModel {
    
    private int science;
    private int english;
    private int sinhala;
    private int maths;
    private int ict;

    public ScoreModel(int science, int english, int sinhala, int maths, int ict) {
        this.science = science;
        this.english = english;
        this.sinhala = sinhala;
        this.maths = maths;
        this.ict = ict;
    }

    public int calculateTotalMarks() {
        return science + english + sinhala + maths + ict;
    }

    public double calculateAverage() {
        return calculateTotalMarks() / 5.0;
    }

    // Getters and Setters (if needed)
}
    

