/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author chavani
 */

import java.sql.SQLException;
import java.sql.Statement;

public class AddRecord {
   
    Statement stmt;
    
    public void studentdetails(String StID, String SFName,String SMame,String SLName,String SDOB,String SGender,String SPhoneNum,String SNIC,String SAddress1,String SAddress2 int Tele, String ID, String pass){
        try {
            stmt =DBConnection.getStatementConnection();
            
            stmt.executeUpdate("INSERT INTO cashier VALUES ('"+Name+"', '"+NIC+"', '"+Tele+"',  '"+ID+"', '"+pass+"')");
            
        }
        catch (SQLException e){
    }
    }
    
    public void AddAdmin(String Name, String NIC, int Tele, String ID, String pass){
       try {
            stmt = DBConnection.getStatementConnection();
            
            stmt.executeUpdate("INSERT INTO adminl VALUES('"+Name+"', '"+NIC+"', '"+Tele+"', '"+ID+"','"+pass+"')");
        }
        catch(SQLException e){
        } 
 
    }
    
    public void AddProduct(String Pname, String pcode, String category, double wsp, double rp){
        try {
            stmt = DBConnection.getStatementConnection();
            
            stmt.executeUpdate("INSERT INTO product VALUES('"+Pname+"', '"+category+"', '"+wsp+"', '"+rp+"', '"+pcode+"')");
        }
        catch(SQLException e){
        }
    }
    
    public void AddSupplier(String Sname,String SID,String category,int Tele){
         try {
            stmt = DBConnection.getStatementConnection();
            
            stmt.executeUpdate("INSERT INTO supplier VALUES('"+Sname+"', '"+SID+"', '"+category+"', '"+Tele+"')");
        }
        catch(SQLException e){
        }
        
    }
    
    
    public void AddCustomer(String Name, String NIC ,int Tele){
        try {
            stmt = DBConnection.getStatementConnection();
            
            stmt.executeUpdate("INSERT INTO customer VALUES('"+Name+"', '"+NIC+"', '"+Tele+"')");
        }
        catch(SQLException e){
        }
    }
    
}

public class AddRecored {
    
}
