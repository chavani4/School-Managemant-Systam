/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author User
 */
public class Student {
    private String studentId;
    private int science;
    private int english;
    private int sinhala;
    private int maths;
    private int ict;

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public int getScience() {
        return science;
    }

    public void setScience(int science) {
        this.science = science;
    }

    public int getEnglish() {
        return english;
    }

    public void setEnglish(int english) {
        this.english = english;
    }

    public int getSinhala() {
        return sinhala;
    }

    public void setSinhala(int sinhala) {
        this.sinhala = sinhala;
    }

    public int getMaths() {
        return maths;
    }

    public void setMaths(int maths) {
        this.maths = maths;
    }

    public int getIct() {
        return ict;
    }

    public void setIct(int ict) {
        this.ict = ict;
    }

    public int calculateTotalMarks() {
        return science + english + sinhala + maths + ict;
    }

    public double calculateAverage() {
        return calculateTotalMarks() / 5.0;
    }
}
public class student {
    
}
